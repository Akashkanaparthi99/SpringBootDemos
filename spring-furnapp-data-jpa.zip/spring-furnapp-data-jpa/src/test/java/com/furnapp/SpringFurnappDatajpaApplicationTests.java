package com.furnapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFurnappDatajpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
