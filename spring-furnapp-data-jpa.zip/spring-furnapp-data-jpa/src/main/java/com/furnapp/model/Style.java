package com.furnapp.model;

public enum Style {

    MODERN,
    CONTEMPORARY,
    TRADITIONAL,
    MID_CENTURY;
}
