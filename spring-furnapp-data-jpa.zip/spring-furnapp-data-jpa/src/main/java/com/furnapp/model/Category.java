package com.furnapp.model;

public enum Category {
    CHAIR,
    TABLE,
    BEDS,
    SOFA,
    CABINETRY,
    STORAGE,
    OFFICE_FURNITURE;
}
